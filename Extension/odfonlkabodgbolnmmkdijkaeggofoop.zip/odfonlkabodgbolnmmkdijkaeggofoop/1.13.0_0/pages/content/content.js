const ClearlyEnv = window.ClearlyEnv || {}

function stopKeyZoom (event) {
  if ((event.metaKey || event.ctrlKey) && [48, 61, 96, 107, 109, 187, 189].indexOf(event.keyCode) > -1) {
    event.preventDefault()
  }
}

// eslint-disable-next-line no-unused-vars
class Content {
  static toggle () {
    if (Content.isOpen()) {
      Content.close()
    } else {
      Content.open()
    }
  }

  static open () {
    Content.sendFrame({
      type: 'UPDATE',
      url: window.location.href,
      article: Content.getArticle()
    })
    document.body.classList.add('clearly-enabled')
    document.getElementById('clearly-container').style.display = 'inherit'
    Content.callBackground('updateIcon', { status: 'active' })
    document.addEventListener('keydown', stopKeyZoom)
  }

  static close () {
    document.body.classList.remove('clearly-enabled')
    document.getElementById('clearly-container').style.display = 'none'
    Content.callBackground('updateIcon', { status: 'readable' })
    Content.callBackground('speakStop')
    document.removeEventListener('keydown', stopKeyZoom)
  }

  static isOpen () {
    return document.getElementById('clearly-container').style.display !== 'none'
  }

  static sendFrame (message) {
    debug('sendFrame', message, !!Content.frameEl)
    Content.frameEl && Content.frameEl.contentWindow.postMessage(message, '*')
  }

  static getArticle () {
    // eslint-disable-next-line no-undef
    // if (isProbablyReaderable(document)) {
    return new Clearly(document.cloneNode(true), { root: document, debug: ClearlyEnv.debug }).parse()
    // }
    // if (isProbablyReaderable(document)) {
    //   return new Readability(document.cloneNode(true)).parse()
    // }
    // return null
  }

  static update () {
    debug('update')
    Content.sendFrame({
      type: 'UPDATE',
      article: Content.getArticle()
    })
  }

  static async init (config) {
    debug('init')
    const frameURL = chrome.extension.getURL('/pages/content/app.html')
    const chromBaseUrl = chrome.extension.getURL('/')

    const origHtml = await (await window.fetch(frameURL)).text()
    const tmpHtml = origHtml.replace(/(src|href)="\//g, `$1="${chromBaseUrl}`)

    const html = tmpHtml.replace('<!-- clearly placeholder -->', `<textarea id="config" style="display:none">${JSON.stringify(config)}</textarea><textarea id="env" style="display:none">${JSON.stringify(ClearlyEnv)}</textarea>`)

    const frameEl = document.createElement('iframe')
    frameEl.allowFullscreen = true
    frameEl.src = `data:text/html;charset=utf-8, ${escape(html)}`
    frameEl.style.display = 'none'
    frameEl.id = 'clearly-container'
    frameEl.referrerPolicy = 'origin-when-cross-origin'

    frameEl.onload = function () {
      // debug('frame.onload', frameEl.contentWindow)
      Content.update()
    }

    const styleEl = document.createElement('style')
    styleEl.innerHTML = `
.clearly-enabled {
  overflow: hidden;
}

#clearly-container {
  position: fixed;
  top: 0;
  right: 0;
  width: 100%;
  height: 100%;
  border: none;
  overflow: auto;
  display: none !important;
  z-index: 2147483647;
}

.clearly-enabled #clearly-container {
  display: block !important;
}
`

    document.body.appendChild(frameEl)
    document.body.appendChild(styleEl)

    Content.frameEl = frameEl
    Content.styleEl = styleEl
  }

  static remove () {
    document.body.removeChild(this.frameEl)
    document.body.removeChild(this.styleEl)
    Content.frameEl = null
    Content.styleEl = null
  }

  static callBackground (type, data) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ ...data || {}, type }, (res) => {
        const { error, result } = res || {}
        if (chrome.runtime.lastError) {
          debug(`call ${type} failed with runtime error`)
          return resolve()
        }
        if (error) return reject(error)
        resolve(result)
      })
    })
  }

  static fullscreen (data) {
    const frame = Content.frameEl
    if (!data.fullscreen) {
      const cancelFullScreen = document.cancelFullScreen || document.webkitCancelFullScreen || document.mozCancelFullScreen
      cancelFullScreen.call(document)
    } else {
      const requestFullScreen = frame.requestFullScreen || frame.webkitRequestFullScreen || frame.mozRequestFullScreen || false
      requestFullScreen && requestFullScreen.call(frame)
    }
  }

  static handleFrameMessage (data) {
    debug('handleFrameMessage', data)
    if (typeof Content[data.type] === 'function') Content[data.type].call(null, data)
  }

  static isSupportUrl (clearly, url) {
    const blacklist = Content.urlToRegexp(clearly.blacklist)
    const whitelist = Content.urlToRegexp(clearly.whitelist)

    const isWhite = whitelist.some(regex => regex.test(url))
    if (isWhite) return true

    const isBalck = blacklist.some(regex => regex.test(url))
    if (isBalck) return false

    return true
  }

  static urlToRegexp (list) {
    return list.map(item => {
      const regexStr = item
        .replace(/[-[]\/\{\}\(\)\+\?\.\\\^\$\|]/g, '\\$&')
        .replace(/\*/g, '.*?')
        .replace(/^http:\\\/\\\/\.\*/i, 'http:\\/\\/[^/]*')
        .replace(/^https:\\\/\\\/\.\*/i, 'https:\\/\\/[^/]*')
      return new RegExp('^' + regexStr + '$', 'i')
    })
  }

  static async bootstrap (force) {
    const config = await Content.callBackground('getConfig')
    // console.log('config', config)

    if (
      !force &&
      (!document.contentType.includes('/html') || !Content.isSupportUrl(config.clearly, window.location.href))
    ) {
      Content.callBackground('updateIcon', { status: 'disable' })
      return
    }

    Content.init(config)
    Content.callBackground('updateIcon', { status: 'readable' })

    // Listen frame message
    window.addEventListener('message', async function (e) {
      debug('Window Message', e.data)
      const data = e.data
      if (!data || !data.type) return
      if (data.background) {
        debug('Send to background', data)
        let result
        let error
        try {
          result = await Content.callBackground(data.type, data)
        } catch (err) {
          error = err.message
        }
        if (data.callback) {
          Content.sendFrame({ callback: data.callback, result, error })
        }
      } else {
        Content.handleFrameMessage(data)
      }
    }, false)

    chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
      if (!request.frame) return
      Content.sendFrame(request)
    })
  }
}

Content.bootstrap()

// ready(function () {
//   Content.update()
// })

function debug () {
  if (!ClearlyEnv.debug) return
  const args = Array.prototype.slice.call(arguments, 0)
  console.debug.apply(null, ['[CLEARY/CONTENT] '].concat(args))
}

// function ready (fn) {
//   if (document.readyState !== 'loading') {
//     fn()
//   } else if (document.addEventListener) {
//     document.addEventListener('DOMContentLoaded', fn)
//   } else {
//     document.attachEvent('onreadystatechange', function () {
//       if (document.readyState !== 'loading') { fn() }
//     })
//   }
// }
