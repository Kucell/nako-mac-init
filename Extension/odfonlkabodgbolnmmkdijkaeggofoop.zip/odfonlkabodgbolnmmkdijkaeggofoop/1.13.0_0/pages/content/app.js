/* eslint-disable no-undef */
const QUOTES = [
  '“A reader lives a thousand lives before he dies . . . The man who never reads lives only one.” – George R.R. Martin,',
  '“Until I feared I would lose it, I never loved to read. One does not love breathing.” – Harper Lee',
  '“Never trust anyone who has not brought a book with them.” – Lemony Snicket',
  '“You can never get a cup of tea large enough or a book long enough to suit me.” – C.S. Lewis',
  '“Reading is essential for those who seek to rise above the ordinary.” – Jim Rohn',
  '“I find television very educating. Every time somebody turns on the set, I go into the other room and read a book.” – Groucho Marx',
  '“‘Classic’, a book which people praise and don’t read.” – Mark Twain',
  '“You don’t have to burn books to destroy a culture. Just get people to stop reading them.” – Ray Bradbury',
  '“So please, oh please, we beg, we pray, go throw your TV set away, and in its place you can install a lovely bookshelf on the wall.” – Roald Dahl',
  '“Think before you speak. Read before you think.” – Fran Lebowitz',
  '“Let’s be reasonable and add an eighth day to the week that is devoted exclusively to reading.” – Lena Dunham',
  '“The reading of all good books is like conversation with the finest (people) of the past centuries.” – Descartes',
  '“In the case of good books, the point is not to see how many of them you can get through, but rather how many can get through to you.” – Mortimer J. Adler',
  '“Reading one book is like eating one potato chip.” – Diane Duane',
  '“The more that you read, the more things you will know. The more that you learn, the more places you’ll go.” – Dr. Seuss',
  'Like Dr. Suess? Want to see our entire collection of quotes from Dr. Suess?',
  '“Books are a uniquely portable magic.” – Stephen King',
  '“I read a book one day and my whole life was changed.” – Orhan Pamuk',
  '“People say that life is the thing, but I prefer reading.” – Logan Pearsall Smith',
  '“Today a reader, tomorrow a leader.” – Margaret Fuller',
  '“People can lose their lives in libraries. They ought to be warned.” – Saul Bellow'
]

class App {
  constructor () {
    this.callbackStart()
    // this.bootstrap()
  }

  load (content, force) {
    if (!this.boot && !force) return false
    const article = this.article = content.article
    this.url = content.url

    if (!article) {
      const quote = QUOTES[Math.floor(Math.random() * QUOTES.length)]
      const [text, author] = quote.split(' – ')
      $('#content').html(DOMPurify.sanitize(`<div class="quote"><div class="quote-text">${text}</div><div class="quote-author">${author}</div></div>`, { SAFE_FOR_JQUERY: true }))
      return false
    }

    if (
      article.outline &&
      article.outline.length &&
      article.outline[0].id !== ''
    ) {
      article.outline.unshift({
        title: article.title,
        id: '',
        type: 'h1'
      })
    }
    if (article.outline) {
      $('#outline').html(
        DOMPurify.sanitize(
          article.outline.map(section => '<div class="outline-section outline-' +
            section.type + '"><a href="javascript:;" data-id="#' +
            section.id + '">' +
            section.title +
            '</a></div>'
          ).join('\n')
          , { SAFE_FOR_JQUERY: true })
      )
      if (!article.outline.length) {
        $('#switch-outline').addClass('s-disable')
      }
    }
    $('#title').html(DOMPurify.sanitize(article.title, { SAFE_FOR_JQUERY: true }))
    $('#content').html(DOMPurify.sanitize(article.content, { SAFE_FOR_JQUERY: true }))
    if (article.authorName) {
      $('#byline').html(DOMPurify.sanitize(article.authorName ? article.authorName + ' @' + article.hostname : '', { SAFE_FOR_JQUERY: true }))
    }

    $('#btn-cantact').attr('href', 'https://clearlyreader.com/r/report?url=' + encodeURIComponent(this.url))

    this.callBackground('submitArticle', { article })

    return true
  }

  closePopmenu (event) {
    this.lastSelection = null
    this.setState({ popupOverlayData: null })
    $('#popmenu').hide()
    $('#poptranslate').hide()
    $('#popshare').hide()
    $('body').off('click', this.closePopmenu.bind(this))
  }

  clickPopmenu (type) {
    const selectedText = window.getSelection().toString()
    if (!selectedText) return
    this.lastSelectedText = selectedText
    switch (type) {
      case 'translate':
        this.startPopTranslate(selectedText)
        break
      case 'copy':
        document.execCommand('copy')
        // this.closePopmenu()
        break
      case 'search':
        this.callBackground('getSearch', { keyword: selectedText })
          .then(data => this.showPopmenuOverlay({ type: 'search', data }))
        break
      case 'wiki':
        this.callBackground('getWiki', { text: selectedText })
          .then(data => this.showPopmenuOverlay({ type: 'wiki', data }))
        break
      case 'share':
        html2canvas(document.querySelector('#root')).then(canvas => {
          document.body.appendChild(canvas)
        })
        break
    }
  }

  showPopmenuOverlay (data) {
    this.setState({ popupOverlayData: data })
  }

  keepSelection () {
    if (!this.lastSelection) return

    let currentSelection = window.getSelection()
    let currentSelectedText = currentSelection.toString()
    let lastSelectionRanges = this.lastSelection.ranges

    if (currentSelectedText) {
      currentSelection.removeAllRanges()
    }

    for (let i = 0, len = lastSelectionRanges.length; i < len; ++i) {
      currentSelection.addRange(lastSelectionRanges[i])
    }
  }

  async startPopTranslate (selectedText) {
    try {
      const res = await this.translate(selectedText, this.config.translateLang)
      this.showPopmenuTranslate(res)
    } catch (err) {
      debug('error', err)
      // show warning
    }
  }

  showPopmenu () {
    let pos = this.lastSelection.position
    $('#poptranslate').hide()
    $('#popmenu').show()
    $('#popmenu').css({
      left: (window.pageXOffset + pos.x + (pos.width - $('#popmenu').width()) / 2) * parseInt(this.config.zoom || 1, 10),
      top: (window.pageYOffset + pos.y - $('#popmenu').height() - 10) * parseInt(this.config.zoom || 1, 10)
    })
    setTimeout(() => {
      $('body').on('click', this.closePopmenu.bind(this))
    }, 100)
  }

  showPopmenuTranslate (data) {
    let pos = this.lastSelection.position
    $('#popmenu').hide()
    $('#poptranslate').show()

    let contentHtml = data.sentences.map(result => result.trans || '').join('')
    $('#poptranslate-explain').html(contentHtml)
    $('#poptranslate-voice').hide()

    if (data.dict) {
      $('#poptranslate').addClass('poptranslate-wordmode')
      let nouce = data.sentences.find(item => item.translit)
      if (nouce.src_translit) {
        $('#poptranslate-voice span').html(`[${nouce.src_translit}]`)
        $('#poptranslate-voice').show()
      }
      $('#poptranslate-translit').html(nouce.translit || '')
      $('#poptranslate-word').html(this.lastSelection.text)
      let dictHtml = data.dict
        .map(item => `${item.pos[0]}. ${item.terms.join('; ')}`)
        .join('<br />')
      $('#poptranslate-dict').html(dictHtml)
    } else {
      $('#poptranslate').removeClass('poptranslate-wordmode')
    }

    $('#poptranslate').css({
      left:
        window.pageXOffset +
        pos.x +
        (pos.width - $('#poptranslate').width()) / 2,
      top:
        window.pageYOffset +
        pos.y -
        $('#poptranslate').height() -
        30
    })
  }

  getAndSaveSelection () {
    let selection = window.getSelection()
    let selectedText = selection.toString()
    if (!selectedText) return false

    let ranges = []
    if (selection.rangeCount) {
      for (let i = 0, len = selection.rangeCount; i < len; ++i) {
        ranges.push(selection.getRangeAt(i))
      }
    }

    this.lastSelection = {
      ranges,
      text: selectedText,
      position: selection.getRangeAt(0).getBoundingClientRect()
    }

    return true
  }

  /**
   * = END
   * Popmenu and poptranslate features
   */

  show (data, force) {
    if (!this.load(data, force)) return
    this.sendGA(['_trackEvent', 'POPUP_CLICK', 'APP_SHOW'])
  }

  /**
   * App Actions
   *
   * @param {String} key
   * @param {Mixed} value
   */
  action (key, value) {
    debug('action', key, value)
    switch (key) {
      case 'close':
        this.callParent({ type: 'fullscreen', fullscreen: false })
        this.callParent({ type: 'close' })
        this.stopAll()
        break
      case 'share':
        this.setState({ isSharing: value })
        this.callBackground('submitFeedback', {
          article: this.article,
          feedback: value.toUpperCase()
        })
        break
      case 'toggleOutline':
        this.setConfig({ outline: !this.config.outline })
        break
      case 'toggleAutotheme':
        this.setConfig({ themeAuto: !this.config.themeAuto })
        break
      case 'zoomIn':
        this.setConfig({ zoom: ((parseFloat(this.config.zoom, 10) || 1) - 0.1).toFixed(2) })
        break
      case 'zoomOut':
        this.setConfig({ zoom: ((parseFloat(this.config.zoom, 10) || 1) + 0.1).toFixed(2) })
        break
      case 'print':
        window.print()
        break
      case 'exportPDF':
        // html2pdf(document.body).set({
        //   image: { type: 'jpeg' },
        //   html2canvas: { scale: 1.2 },
        //   jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
        // }).from().save()
        break
      case 'theme':
        this.setConfig({ theme: value })
        break
      case 'themeDay':
        this.setConfig({ themeDay: value })
        break
      case 'themeNight':
        this.setConfig({ themeNight: value })
        break
      case 'speakText':
        this.callBackground('speakPlay', { text: value }, _ => (this.setState({ speak: null })))
        break
      case 'speak':
        let speakType, speakData
        switch (this.state.speak) {
          case 'PLAY':
          case 'START':
          case 'RESUME':
            speakType = 'Pause'
            break
          case 'PAUSE':
            speakType = 'Resume'
            break
          default:
            speakType = 'Start'
            speakData = {
              text: this.article ? this.article.title + '。' + this.article.textContent : document.getElementById('content').innerText
            }
        }
        this.callBackground(`speak${speakType}`, speakData || {}, _ => this.setState({ speak: speakType && speakType.toUpperCase() }))
        break
      case 'toggleFullscreenMode':
        this.setState({ fullscreen: !this.state.fullscreen })
        this.callParent({
          type: 'fullscreen',
          fullscreen: this.state.fullscreen
        })
        break
      case 'showDialog':
        this.setState({ showDialog: value })
        break
      case 'changeLanguage':
        this.setConfig({ translateLang: value })
        this.startPopTranslate(this.lastSelectedText)
        break
      case 'font':
        this.setConfig({ [`font_${this.state.lang}`]: value })
        break
      case 'report':
        window.open('https://clearlyreader.com/r/report?url=' + encodeURIComponent(this.url))
        break
    }

    this.sendGA([
      '_trackEvent',
      'APP_ACTION',
      'ACTION_' + key.toUpperCase(),
      'ACTION_VALUE_' + String(value).toUpperCase()
    ])
  }

  /**
   * Update state event
   *
   * @param {String} key
   * @param {Mixed} value
   * @param {Mixed} oldValue
   */
  handleState (key, value, oldValue) {
    debug('handleState', key, value, oldValue)
    switch (key) {
      case 'speak':
        switch (value) {
          case 'PLAY':
          case 'START':
          case 'RESUME':
            $('#menu-speak').addClass('menu-actived')
            $('#menu-speak .material-icons').text('volume_up')
            break
          case 'PAUSE':
            $('#menu-speak').addClass('menu-actived')
            $('#menu-speak .material-icons').text('volume_off')
            break
          default:
            $('#menu-speak').removeClass('menu-actived')
            $('#menu-speak .material-icons').text('volume_down')
        }
        break
      case 'fullscreen':
        if (value) {
          $('#menu-fullscreen').addClass('menu-actived')
          $('#menu-fullscreen .material-icons').text('fullscreen_exit')
        } else {
          $('#menu-fullscreen').removeClass('menu-actived')
          $('#menu-fullscreen .material-icons').text('fullscreen')
        }
        break
      case 'isSharing':
        $('.share-overlay').hide()
        switch (value) {
          case 'yes':
            $('#share-yes').show()
            break
          case 'no':
            $('#share-no').show()
            break
          case 'finish':
          default:
            $('#share-default').show()
        }
        break
      case 'showDialog':
        $('.dialog').removeClass('dialog--open')
        switch (value) {
          case 'style':
            $('#dialog-style').addClass('dialog--open')
            break
          case 'setting':
            $('#dialog-setting').addClass('dialog--open')
            break
        }
        break
      case 'fonts':
        $('#font-select-style').html('')
        value.forEach(f => {
          let fontValue = f.name.toLowerCase().replace(/ /g, '')
          let className = 'font-' + fontValue
          if (this.state && this.config[`font_${this.state.lang}`] === fontValue) {
            className += ' font-selected'
          }
          $('#font-select-style').append(
            DOMPurify.sanitize(`<span data-font="${fontValue}" class="${className}">${f.name}</span>`, { SAFE_FOR_JQUERY: true })
          )
        })
        break
      case 'popupOverlayData':
        if (value) {
          const results = value.data.results.slice(0, 5)
          $('#popmenu-overlay').html('')
          results.forEach(item => {
            $('#popmenu-overlay').prepend(`<a target="clearly-wiki" href="${item.link}"><div class="popmenu-overlay-item">
            <label>${item.title}</label>
            <div>${item.intro}</div>
          </div></a>`)
          })
          $('#popmenu-overlay').show()
        } else {
          $('#popmenu-overlay').hide()
          $('#popmenu-overlay').html('')
        }
        break
    }
  }

  /**
   * Config update
   *
   * @param {String} key
   * @param {Mixed} value
   * @param {Mixed} oldValue
   */
  handleConfig (key, value, oldValue) {
    debug('handleConfig', arguments)

    switch (key) {
      case 'theme':
        $('#themes .btn-selected').removeClass('btn-selected')
        $(`#themes .btn-theme-${value}`).addClass('btn-selected')
        this.selectTheme()
        break
      case 'themeDay':
        $('#themes-day .btn-selected').removeClass('btn-selected')
        $(`#themes-day .btn-theme-${value}`).addClass('btn-selected')
        this.selectTheme()
        break
      case 'themeNight':
        $('#themes-night .btn-selected').removeClass('btn-selected')
        $(`#themes-night .btn-theme-${value}`).addClass('btn-selected')
        this.selectTheme()
        break
      case 'zoom':
        document.getElementById('content').style.zoom = value
        $('#value-zoom').text((value * 100).toFixed(0) + '%')
        break
      case 'themeAuto':
        if (value) {
          $('#themes-day').show()
          $('#themes-night').show()
          $('#themes').hide()
          $('#switch-theme').addClass('s-on')
          $('#switch-theme').removeClass('s-off')
        } else {
          $('#themes-day').hide()
          $('#themes-night').hide()
          $('#themes').show()
          $('#switch-theme').removeClass('s-on')
          $('#switch-theme').addClass('s-off')
        }
        this.selectTheme()
        break
      case 'outline':
        if (value) {
          $('#outline').show()
          $('#switch-outline').addClass('s-on')
          $('#switch-outline').removeClass('s-off')
        } else {
          $('#outline').hide()
          $('#switch-outline').removeClass('s-on')
          $('#switch-outline').addClass('s-off')
        }
        break
      case 'translateLang':
        $('#poptranslate-lang').val(value)
        break
      default:
        // Font control
        if (key.startsWith('font_')) {
          $('.font-selected').removeClass('font-selected')
          $(`.font-${value}`).addClass('font-selected')
          $('#main,#outline').attr('class', '')
          $('#main,#outline').addClass('font-' + value)
        }
    }
    this.saveConfig()
  }

  selectTheme () {
    const autoTheme = this.config && this.config.themeAuto
    let selectedTheme = 'default'

    if (autoTheme) {
      const isNight = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches
      selectedTheme = this.config[isNight ? 'themeNight' : 'themeDay']
    } else {
      selectedTheme = this.config.theme
    }

    $('html').attr('class', `theme-${selectedTheme}`)
  }

  /**
   * Save config
   */
  saveConfig () {
    if (!this.config) return
    debug('saveConfig', this.config)
    return this.callBackground('saveConfig', { config: this.config })
    // chrome.storage.local.set({ config: this.config }, function () {
    //   // console.debug('saveConfig', this.config)
    // })
  }

  /**
   * Send GA
   *
   * @param {Array} data
   */
  sendGA (data) {
    this.callBackground('ga', { data })
  }

  // Send message
  callParent (data) {
    debug('sendParent', data)
    parent.postMessage(data, '*')
    // chrome.tabs.sendBackground(this.tabId, data, cb)
  }

  callBackground (type, data) {
    debug('callBackgroud', type, data)
    return new Promise((resolve, reject) => {
      const callback = String(Math.random())

      this.callbackWait(callback, (err, res) => {
        if (err) return reject(err)
        resolve(res)
      })

      parent.postMessage({
        ...data || {},
        background: true,
        type,
        callback
      }, '*')
    })
  }

  callbackWait (id, fn) {
    debug('callbackWait', id, fn)
    this.callbacks[id] = { fn, ts: Date.now() }
  }

  callbackReceive (id, result, error) {
    debug('callbackReceive', id, error, result)
    const { fn } = this.callbacks[id] || {}
    if (!fn) return
    fn(error, result)
  }

  callbackStart () {
    debug('callbackLoop')
    if (!this.callbacks) this.callbacks = {}
    window.setInterval(_ => {
      const cs = Date.now()
      Object.keys(this.callbacks).forEach(id => {
        const { fn, ts } = this.callbacks[id]
        let error = null
        let result = null
        if (cs - ts > 10000) {
          delete this.callbacks[id]
          error = new Error(`call "${id}" timeout`)
          fn(error, result)
        }
      })
    }, 1000)
  }

  /**
   * Stop all actived
   */
  stopAll () {
    if (!this.state.speak) return
    this.callBackground('speakStop').then(() => this.setState({ speak: null }))
  }

  /**
   * Translate
   *
   * @param {String} text
   * @param {Function} cb
   */
  translate (text, lang) {
    return this.callBackground('translate', { lang, text })
  }

  /**
   * Scroll to element
   *
   * @param {Element} destination
   */
  scrollIt (destination) {
    const rootElem = document.body
    const documentHeight = Math.max(
      rootElem.scrollHeight,
      rootElem.offsetHeight,
      document.documentElement.clientHeight,
      document.documentElement.scrollHeight,
      document.documentElement.offsetHeight
    )
    const windowHeight =
      window.innerHeight ||
      document.documentElement.clientHeight ||
      rootElem.clientHeight
    const destinationOffset =
      typeof destination === 'number' ? destination : destination.offsetTop
    const destinationOffsetToScroll = Math.round(
      documentHeight - destinationOffset < windowHeight
        ? documentHeight - windowHeight
        : destinationOffset
    )
    window.scroll(0, destinationOffsetToScroll)
  }

  /**
   * Bind events
   */
  bindEvents () {
    $('#outline').on('click', '.outline-section a', (e) => {
      let selector = $(e.target).data('id')
      if (selector === '#' || !selector) return window.scroll(0, 0)
      let element = document.querySelector(selector)
      element && this.scrollIt(element)
    })

    $('#btn-speak').click(() => this.action('speak'))
    $('#btn-report').click(() => this.action('report'))
    $('#themes .btn-theme-default').click(() => this.action('theme', 'default'))
    $('#themes .btn-theme-yellow').click(() => this.action('theme', 'yellow'))
    $('#themes .btn-theme-black').click(() => this.action('theme', 'black'))
    $('#themes .btn-theme-gray').click(() => this.action('theme', 'gray'))

    $('#themes-day .btn-theme-default').click(() => this.action('themeDay', 'default'))
    $('#themes-day .btn-theme-yellow').click(() => this.action('themeDay', 'yellow'))
    $('#themes-night .btn-theme-black').click(() => this.action('themeNight', 'black'))
    $('#themes-night .btn-theme-gray').click(() => this.action('themeNight', 'gray'))

    $('#btn-close').click(() => this.action('close'))
    $('#btn-print').click(() => this.action('print'))
    $('#btn-pdf').click(() => this.action('exportPDF'))
    $('#btn-zoomin').click(() => this.action('zoomIn'))
    $('#btn-zoomout').click(() => this.action('zoomOut'))
    $('#switch-outline').click(() => this.action('toggleOutline'))
    $('#switch-theme').click(() => this.action('toggleAutotheme'))
    // $('#menu-translate').click(this.toggleTranslate)
    $('#menu-fullscreen').click(() => this.action('toggleFullscreenMode'))

    // Style setting
    $('#btn-style').click(() => this.action('showDialog', 'style'))

    $('.dialog-btn-close').click(() => this.action('showDialog', null))

    // Share
    $('#btn-thumb-up').click(() => this.action('share', 'yes'))
    $('#btn-thumb-down').click(() => this.action('share', 'no'))

    // Popmenu
    $('#content,#title').click(e => {
      setTimeout(_ => {
        if (this.getAndSaveSelection()) {
          this.showPopmenu(event)
          e.stopPropagation()
        }
      }, 100)
    })

    $('.popmenu-item').click((e) => this.clickPopmenu($(e.target).data('type')))
    $('#popmenu,#popshare,#poptranslate').click(e => {
      this.keepSelection()
      e.stopPropagation()
    })

    // Translate lang change
    $('#poptranslate-lang').change((e) => this.action('changeLanguage', $(e.target).val()))

    // Speak text
    $('#poptranslate-btn-speak').click(() => this.action('speakText', $('#poptranslate-word').text()))

    // Change font
    $('#font-select-style').on('click', 'span', (e) => {
      this.action('font', $(e.target).data('font'))
    })

    $('html').on('keyup', (e) => {
      if (e.originalEvent.code === 'Escape') {
        this.action('close')
        this.sendGA(['_trackEvent', 'SHORTCUT', 'APP_HIDE'])
      }
    })
  }

  handleParentMessage (data) {
    if (!data) return

    if (data.callback) {
      return this.callbackReceive(data.callback, data.result, data.error)
    }

    switch (data.type) {
      case 'UPDATE':
        this.show(data, true)
        break
      case 'SPEAK':
        this.setState({ speak: data.speak ? data.speak.toUpperCase() : null })
        break
      case 'CONTENT_PARSE':
        this.setState({ isReady: false })
        break
      case 'CONTENT_LANG':
        this.setState({ lang: data.lang })
        break
    }
  }

  setIcon (status) {
    this.callBackground('updateIcon', { status })
  }

  getTabId () {
    return this.callBackground('getTabId')
  }

  getDefaultState () {
    return {
      speak: null,
      fullscreen: false,
      isReady: true,
      isTranslate: false,
      translateResult: null,
      isSharing: false,
      fonts: [
        {
          name: 'Lora',
          lang: ['en'],
          system: ['win', 'mac']
        },
        {
          name: 'NotoSerif',
          lang: ['en'],
          system: ['win', 'mac']
        },
        {
          name: 'Crimson Text',
          lang: ['en'],
          system: ['win', 'mac']
        },
        {
          name: 'Georgia',
          lang: ['en'],
          system: ['win', 'mac']
        },
        {
          name: 'Roboto',
          lang: ['en'],
          system: ['win', 'mac']
        },
        {
          name: 'Kaiti',
          lang: ['zh'],
          system: ['win', 'mac']
        },
        {
          name: 'Songti',
          lang: ['zh'],
          system: ['win', 'mac']
        },
        {
          name: 'System',
          lang: ['zh', 'en'],
          system: ['win', 'mac']
        }
        // ,
        // {
        //   name: 'SimHei',
        //   lang: ['zh'],
        //   system: ['win']
        // }
      ]
    }
  }

  setState (obj) {
    if (!this.state) this.state = {}
    Object.keys(obj).forEach(key => {
      const oldValue = this.state[key]
      this.state[key] = obj[key]
      this.handleState(key, obj[key], oldValue)
    })
  }

  setConfig (obj) {
    if (!this.config) this.config = {}
    Object.keys(obj).forEach(key => {
      const oldValue = this.config[key]
      this.config[key] = obj[key]
      this.handleConfig(key, obj[key], oldValue)
    })
  }

  /**
   * Bootstrap
   */
  async bootstrap () {
    window.addEventListener('message', (e) => {
      debug('Frame received message', e.data)
      this.handleParentMessage(e.data)
    }, false)

    const config = await this.callBackground('getConfig')
    this.setConfig(config)
    this.setState(this.getDefaultState())
    this.boot = true
    this.bindEvents()
  }
}

const app = window.app = new App()
app.bootstrap()

function debug () {

  // const args = Array.prototype.slice.call(arguments, 0)
  // console.debug.apply(null, ['CLEARY* |'].concat(args))
}
