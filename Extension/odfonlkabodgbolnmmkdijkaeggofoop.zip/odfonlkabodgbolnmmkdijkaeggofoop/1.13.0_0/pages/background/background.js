/* eslint-disable no-undef */
var _gaq = []
_gaq.push(['_setAccount', 'UA-92398359-4'])
_gaq.push([
  '_set',
  'page',
  '/extension/' + chrome.runtime.getManifest().version + '/background'
])
_gaq.push(['_trackPageview'])
;(function () {
  var ga = document.createElement('script')
  ga.type = 'text/javascript'
  ga.async = true
  ga.src = 'https://ssl.google-analytics.com/ga.js'
  var s = document.getElementsByTagName('script')[0]
  s.parentNode.insertBefore(ga, s)
})()

const CLEARY_CONFIG = {
  whitelist: [
    'news.google.com/*',
    'support.google.com/*',
    'medium.com/*',
    'www.jianshu.com/p/*'
  ],
  blacklist: [
    'www.youtube.com/*',
    'www.google.*',
    'chrome.google.com/*',
    'translate.google.com/*',
    'mail.google.com/*',
    'drive.google.com/*',
    'docs.google.com/*'
  ],
  fonts: [
    {
      name: 'Lora',
      lang: ['en'],
      default: 'en',
      system: ['win', 'mac']
    },
    {
      name: 'NotoSerif',
      lang: ['en'],
      system: ['win', 'mac']
    },
    {
      name: 'Crimson Text',
      lang: ['en'],
      system: ['win', 'mac']
    },
    {
      name: 'Georgia',
      lang: ['en'],
      system: ['win', 'mac']
    },
    {
      name: 'Roboto',
      lang: ['en'],
      system: ['win', 'mac']
    },
    {
      name: 'Kaiti',
      lang: ['zh'],
      default: 'zh',
      system: ['win', 'mac']
    },
    {
      name: 'Songti',
      lang: ['zh'],
      system: ['win', 'mac']
    },
    {
      name: 'System',
      lang: ['zh', 'en'],
      system: ['win', 'mac']
    }
    // ,
    // {
    //   name: 'SimHei',
    //   lang: ['zh'],
    //   system: ['win']
    // }
  ]
}

class Background {
  /**
   * start speak
   */
  speakStart (data) {
    if (!data.text || !data.tabId) {
      console.error('text or tabId not found')
      return
    }

    if (this.speakState) {
      this.sendToFrame({ type: 'SPEAK', speak: this.speakState })
    }

    this.speakState = 'start'
    this.speakTabId = data.tabId

    return new Promise((resolve, reject) => {
      this.detectLanguage({ tabId: this.speakTabId })
        .then(lang => {
          if (!chrome.tts) return reject(new Error('no tts fount'))

          chrome.tts.stop()
          chrome.tts.speak(
            data.text,
            {
              lang,
              rate: 1,
              onEvent: event => {
                switch (event.type) {
                  case 'end':
                  case 'interrupted':
                  case 'cancelled':
                  case 'error':
                    this.speakState = null
                    this.sendToFrame({ type: 'SPEAK', speak: this.speakState })
                    break
                }
              },
              ...data.options
            },
            _ => {
              if (chrome.runtime.lastError) reject(new Error('runtime error'))
              this.sendToFrame({ type: 'SPEAK', speak: this.speakState })
              resolve()
            }
          )
        })
    })
  }

  /**
   * Stop pause
   */
  speakPause () {
    if (!chrome.tts) return
    this.speakState = 'pause'
    chrome.tts.pause()
    this.sendToFrame({ type: 'SPEAK', speak: this.speakState })
  }

  /**
   * Stop resume
   */
  speakResume () {
    if (!chrome.tts) return
    this.speakState = 'start'
    chrome.tts.resume()
    this.sendToFrame({ type: 'SPEAK', speak: this.speakState })
  }

  /**
   * Stop speak
   */
  speakStop () {
    if (!chrome.tts) return
    this.speakState = null
    chrome.tts.stop()
    this.sendToFrame({ type: 'SPEAK', speak: this.speakState })
  }

  sendToFrame (data) {
    if (!this.speakTabId) return
    chrome.tabs.get(this.speakTabId, (tab) => {
      if (!tab) {
        console.warn(`tab ${this.speakTabId}`)
        return
      }

      chrome.tabs.sendMessage(this.speakTabId, { ...data, frame: true })
      if (chrome.runtime.lastError) {
        debug('lastError', chrome.runtime.lastError.message)
      }
    })
  }

  /**
   * Get config
   */
  async getConfig ({ tabId }) {
    const config = {
      theme: 'default',
      zoom: 1,
      outline: true,
      themeDay: 'default',
      themeNight: 'gray',
      themeAuto: false,
      translateLang: navigator.language,
      clearly: CLEARY_CONFIG,
      lang: await this.detectLanguage({ tabId }),
      tabId
    }

    return new Promise((resolve, reject) => {
      chrome.storage.local.get(['config'], (result) => {
        Object.assign(config, result.config || {})
        resolve(config)
      })
    })
  }

  /**
   * save config
   *
   * @param {Object} data
   */
  saveConfig ({ config }) {
    if (!config) return false
    delete config.clearly
    delete config.lang
    delete config.tabId
    return new Promise((resolve, reject) => {
      chrome.storage.local.set({ config }, _ => {
        resolve(true)
      })
    })
  }

  /**
   * Submit article
   *
   * @param {Object} data
   */
  submitArticle (data) {
    return this.callApi('submitArticle', data)
  }

  /**
   * Submit feedback
   *
   * @param {Object} data
   */
  submitFeedback (data) {
    return this.callApi('submitFeedback', data)
  }

  /**
   * Search wiki
   */
  getWiki (data) {
    return this.callApi('card/wiki', data)
  }

  /**
   * Search wiki
   */
  getSearch (data) {
    return this.callApi('card/search', data)
  }

  /**
   * Search wiki
   */
  getTranslate (data) {
    return this.callApi('card/translate', data)
  }

  /**
   * Update icon
   *
   * @param {*} data
   */
  updateIcon ({ status, tabId }) {
    status = status || 'default'

    chrome.browserAction.setIcon({
      path: {
        '16': `/assets/icons/${status}/ic_16.png`,
        '32': `/assets/icons/${status}/ic_32.png`,
        '48': `/assets/icons/${status}/ic_48.png`,
        '128': `/assets/icons/${status}/ic_128.png`
      },
      tabId
    })
  }

  /**
   * Translate text with lang
   *
   * @param {String} text
   * @param {String} lang
   */
  translate ({ text, lang }) {
    let hash = Background.hashCode(JSON.stringify({ text, lang }))
    let result = this.translateResults.get(hash)
    if (result) return result

    return fetch(`https://translate.googleapis.com/translate_a/single?dt=t&dt=bd&dt=qc&dt=rm&client=gtx&sl=auto&tl=${lang}&q=${encodeURIComponent(text)}&hl=en-US&dj=1&tk=${Background.googleToken()}`, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    })
      .then(res => res.json())
      .then(res => {
        this.translateResults.set(hash, res)
        return res
      })
  }

  /**
   * send GA
   */
  ga ({ data }) {
    typeof _gaq !== 'undefined' && _gaq.push(data)
  }

  /**
   * Detect language
   *
   * @param {Object} data
   */
  detectLanguage ({ tabId }) {
    return new Promise((resolve, reject) => {
      chrome.tabs.detectLanguage(tabId, lang => resolve(lang))
    })
  }

  /**
   * Toggle clearly
   */
  toggle () {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      if (!tabs[0]) return
      if (tabs[0].url.startsWith('http')) {
        chrome.tabs.executeScript(null, {
          code:
            "try{Content.toggle()}catch(err){console.debug('ENABLED IREAD FAILED', err)}"
        })
      }
    })
  }

  /**
   * Call server api
   *
   * @param {String} fn
   * @param {Object} data
   */
  callApi (fn, data) {
    return fetch(`https://clearlyreader.com/api/${fn}`, {
      method: 'POST',
      body: JSON.stringify(data),
      headers: {
        'content-type': 'application/json'
      }
    })
      .then(res => res.json())
      .then(res => {
        if (res.code !== 0) throw new Error(`api error ${res.code}`)
        return res.data
      })
  }

  handleMessage (request, sender, sendResponse) {
    console.debug('handleMessage', request)
    const tabId = sender.tab && sender.tab.id

    if (typeof this[request.type] === 'function') {
      const ret = this[request.type]({ ...request, tabId })
      if (ret instanceof Promise) {
        ret.then(result => sendResponse({ result }))
          .catch(error => sendResponse({ error: error.message }))
        return true
      } else {
        sendResponse(ret)
      }
    }
  }

  /**
   * Register chrome
   */
  registerChromeHandlers () {
    this.translateResults = new LRUMap(200)

    if (chrome.tts) {
      chrome.tts.isSpeaking(voices => {
        if (voices && voices.length) chrome.tts.stop()
      })
    }

    chrome.contextMenus.create({
      title: 'Toggle Clearly',
      onclick: this.toggle,
      documentUrlPatterns: ['http://*/*', 'https://*/*']
    })

    chrome.contextMenus.create({
      title: 'Open with Clearly',
      contexts: ['link'],
      onclick: (info, tab) => {
        chrome.tabs.create({
          url: info.linkUrl + '#clearly'
        })
      }
    })

    chrome.commands.onCommand.addListener((command) => {
      switch (command) {
        case 'toggle':
          this.toggle()
          break
      }
    })

    chrome.runtime.onMessage.addListener(this.handleMessage.bind(this))
    chrome.browserAction.onClicked.addListener(() => this.toggle())

    // Init
    chrome.tabs.query({ lastFocusedWindow: true, active: true }, (tabs) => {
      if (!tabs[0]) return
      this.currentTabId = tabs[0].id
    })

    // Update
    chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
      console.debug('TAB UPDATE', { tabId, changeInfo })
      if (changeInfo.status === 'loading') {
        tabId === this.speakTabId && this.speakStop({ force: true })
      }
    })

    chrome.tabs.onRemoved.addListener(tabId => {
      console.debug('TAB REMOVE', { tabId })
      if (tabId === this.speakTabId) {
        this.speakStop({ force: true })
      }
    })

    chrome.tabs.onActivated.addListener(tabInfo => {
      console.debug('TAB ACTIVATED', tabInfo)
      this.currentTabId = tabInfo.tabId
    })

    // chrome.runtime.onInstalled.addListener(details => {
    //   if (details.reason === 'install') {
    //     chrome.tabs.create({ url: 'https://clearlyreader.com/r/install', selected: true })
    //   } else if (details.reason === 'update') {
    //     chrome.tabs.create({ url: 'https://clearlyreader.com/r/upgrade', selected: true })
    //   }
    // })
    // chrome.runtime.setUninstallURL('https://clearlyreader.com/r/uninstall')
  }

  /**
   * Get google token
   */
  static googleToken () {
    return Math.random().toString().substr(2, 7) + '.' + Math.random().toString().substr(2, 7)
  }

  /**
   * Build hash
   * @param {String} str
   */
  static hashCode (str) {
    let hash = 0
    let i
    let chr
    if (str.length === 0) return hash
    for (i = 0; i < str.length; i++) {
      chr = str.charCodeAt(i)
      hash = (hash << 5) - hash + chr
      hash |= 0 // Convert to 32bit integer
    }
    return hash
  }

  /**
   * Bootstrap
   */
  static bootstrap () {
    const app = new Background(window)
    app.registerChromeHandlers()
    return app
  }
}

window.background = Background.bootstrap()
