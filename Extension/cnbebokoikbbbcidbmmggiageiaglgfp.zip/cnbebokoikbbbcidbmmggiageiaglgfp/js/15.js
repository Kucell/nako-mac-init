/**
 * This chrome extension is powered by zao-chrome-extension
 *
 * @see {@link https://gitee.com/zaozaorun/extension}
 * @preserve
 */
(window.webpackJsonp=window.webpackJsonp||[]).push([[15],{d6d708b332f3a8bf507b:function(a,b,s){"use strict";s.r(b);var t=s("327e8160a2b7a9dd01f5"),e=s.n(t),o=s("68362b979a8947f090b7"),c=(s("8af190b70a6bc55c6f1b"),e()(o.a,{status:"403",subTitle:"Sorry, you don't have access to this page."}));b.default=()=>c}}]);