/**
 * This chrome extension is powered by zao-chrome-extension
 *
 * @see {@link https://gitee.com/zaozaorun/extension}
 * @preserve
 */
(window.webpackJsonp=window.webpackJsonp||[]).push([[17],{"4dff2de44aa7a00b2236":function(a,e,n){"use strict";n.r(e);var c=n("8af190b70a6bc55c6f1b"),t=n.n(c);e.default=()=>t.a.createElement(t.a.Fragment,null,"个人设置页")}}]);