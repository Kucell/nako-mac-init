/**
 * This chrome extension is powered by zao-chrome-extension
 *
 * @see {@link https://gitee.com/zaozaorun/extension}
 * @preserve
 */
(window.webpackJsonp=window.webpackJsonp||[]).push([[16],{"793a750c6e5d4ea5d349":function(a,e,s){"use strict";s.r(e);var t=s("327e8160a2b7a9dd01f5"),b=s.n(t),d=s("68362b979a8947f090b7"),o=(s("8af190b70a6bc55c6f1b"),b()(d.a,{status:"404",subTitle:"Sorry, the page you visited does not exist."}));e.default=()=>o}}]);