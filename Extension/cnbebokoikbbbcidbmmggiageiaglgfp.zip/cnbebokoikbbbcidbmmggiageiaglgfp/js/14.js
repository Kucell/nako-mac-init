/**
 * This chrome extension is powered by zao-chrome-extension
 *
 * @see {@link https://gitee.com/zaozaorun/extension}
 * @preserve
 */
(window.webpackJsonp=window.webpackJsonp||[]).push([[14],{"5829bba03043d9acf1b0":function(a,e,b){},"95d37ebb883dc638e852":function(a,e,b){"use strict";b.r(e);var c=b("327e8160a2b7a9dd01f5"),n=b.n(c),s=b("16e94e9df9b67a0835a1"),d=(b("8af190b70a6bc55c6f1b"),b("103be25b8913a0141218"));b("5829bba03043d9acf1b0");e.default=({className:a=""})=>{const{name:e}=Object(d.i)(),b=Object(d.h)(),c=Object(s.l)(b);return n()("div",{className:`extension-iframe ${a} h-100 w-100`},void 0,n()("iframe",{className:"h-100 w-100 b-a-n",src:c.get("href")||""},void 0,e))}}}]);